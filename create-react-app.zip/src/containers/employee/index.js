import React from 'react'


const Employee = () => (
    <div>
        <h1>Employee</h1>
    </div>
)

export default Employee